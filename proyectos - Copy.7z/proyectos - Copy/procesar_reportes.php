<?php
session_start();



// Conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "registro_mileniumfit";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// Verificar que el formulario fue enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $titulo = $conn->real_escape_string($_POST['titulo']);
    $descripcion = $conn->real_escape_string($_POST['descripcion']);
    $foto = $_FILES['foto'];
   

    // Ruta de almacenamiento para las fotos
    $directorio = "uploads/";
    $ruta_foto = $directorio . basename($foto["name"]);

    // Subir la foto al servidor
    if (move_uploaded_file($foto["tmp_name"], $ruta_foto)) {
        // Guardar los datos en la base de datos
        $sql = "INSERT INTO reportes (titulo, descripcion, foto) VALUES ('$titulo', '$descripcion', '$ruta_foto')";
        
        if ($conn->query($sql) === TRUE) {
          // Enviar correo al dueño del sitio
          $destinatario = "kayllerjohanmosqueraalvarez@gmail.com"; // Cambiar por el correo del dueño
          $asunto = "Soporte técnico";
          $contenido = "Una persona te ha enviado un reporte de soporte técnico:\n\n";
          $contenido .= "Título: " . htmlspecialchars($titulo) . "\n";
          $contenido .= "Descripción de falla: " . htmlspecialchars($descripcion) . "\n";
          $contenido .= "Ruta de la foto: " . htmlspecialchars($ruta_foto) . "\n";
          $contenido .= "<a href='http://localhost/proyecto/compradores.php'></a>" . "\n";
          // Cabeceras del correo
          $cabeceras = "From: no-reply@tusitio.com\r\n"; // Cambiar por un correo válido de tu dominio
          $cabeceras .= "Reply-To: " . htmlspecialchars($correo) . "\r\n";
          $cabeceras .= "Content-Type: text/plain; charset=utf-8\r\n";
      
          // Enviar el correo
          if (mail($destinatario, $asunto, $contenido, $cabeceras)) {
              echo "¡Reporte enviado y notificación al correo enviada!";
          } else {
              echo "Reporte enviado, pero no se pudo enviar la notificación al correo.";
          }









        }

        if ($conn->query($sql) === TRUE) {
            echo "¡Reporte publicado";
        } else {
            echo "Error al realizar el reporte: " . $conn->error;
        }
    } else {
        echo "Hubo un error al subir la foto.";
    }
}



header("location:gracias_reporte.php");
exit();
$conn->close();
?>