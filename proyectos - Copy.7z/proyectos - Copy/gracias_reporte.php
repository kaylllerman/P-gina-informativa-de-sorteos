<!DOCTYPE html>
<html lang="es">
<head>
<style>
    
    @media (max-width: 600px) {
    body {
        font-size: 16px;
    }
}
body{background-color:black;

}
h1{text-align:center;
    font-family:Arial;
    font-size:35px;
   color: #F55C27;

}
h4{text-align:center;
    font-family:serif;
    font-size:27px;
    color:#ffd900;

}
img{width: 16px;
    height: 20px;
}


    </style>

<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="UTF-8">
    <title>Gracias por su reporte</title>
</head>
<body>
<a href="iniciar.php">
    <img src="imagenes/flecha.png" alt="">
</a>
    <h1>¡Reporte realizado!</h1>
    <h4>Muchas gracias por su reporte, lo tendremos en cuenta para mejorar la plataforma</h4>
</body>
</html>
