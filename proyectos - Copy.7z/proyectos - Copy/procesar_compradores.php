<?php
session_start();



// Conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "registro_mileniumfit";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// Verificar que el formulario fue enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $conn->real_escape_string($_POST['nombre']);
    $correo = $conn->real_escape_string($_POST['correo']);
    $numero = $conn->real_escape_string($_POST['numero']);
    $ticket = $conn->real_escape_string($_POST['ticket']);
    $foto = $_FILES['foto'];
   

    // Ruta de almacenamiento para las fotos
    $directorio = "uploads/";
    $ruta_foto = $directorio . basename($foto["name"]);

    // Subir la foto al servidor
    if (move_uploaded_file($foto["tmp_name"], $ruta_foto)) {
        // Guardar los datos en la base de datos
        $sql = "INSERT INTO compradores (nombre, correo, numero, ticket, foto) VALUES ('$nombre', '$correo', '$numero', '$ticket', '$ruta_foto')";
       
        if ($conn->query($sql) === TRUE) {
            // Enviar correo al dueño del sitio
            $destinatario = "kayllerjohanmosqueraalvarez@gmail.com"; // Cambiar por el correo del dueño
            $asunto = "Nuevo comprobante enviado";
            $contenido = "Una persona te ha enviado un comprobante:\n\n";
            $contenido .= "Nombre: " . htmlspecialchars($nombre) . "\n";
            $contenido .= "Correo: " . htmlspecialchars($correo) . "\n";
            $contenido .= "Número: " . htmlspecialchars($numero) . "\n";
            $contenido .= "Ticket: " . htmlspecialchars($ticket) . "\n";
            $contenido .= "Ruta de la foto: " . htmlspecialchars($ruta_foto) . "\n";
            $contenido .= "<a href='http://localhost/proyecto/compradores.php'></a>" . "\n";
            // Cabeceras del correo
            $cabeceras = "From: no-reply@tusitio.com\r\n"; // Cambiar por un correo válido de tu dominio
            $cabeceras .= "Reply-To: " . htmlspecialchars($correo) . "\r\n";
            $cabeceras .= "Content-Type: text/plain; charset=utf-8\r\n";
        
            // Enviar el correo
            if (mail($destinatario, $asunto, $contenido, $cabeceras)) {
                echo "¡Comprobante enviado y notificación al correo enviada!";
            } else {
                echo "Comprobante enviado, pero no se pudo enviar la notificación al correo.";
            }
        }
        
        

        if ($conn->query($sql) === TRUE) {
            echo "¡Comprobante enviado!";
        } else {
            echo "Error al guardar el comprobante: " . $conn->error;
        }
    } else {
        echo "Hubo un error al subir la foto.";
    }
}


header("location:confirmacion_participante.php");

$conn->close();
?>


