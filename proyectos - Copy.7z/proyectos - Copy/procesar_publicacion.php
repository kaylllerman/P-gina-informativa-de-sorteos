<?php
session_start();

// Verificar si el usuario es administrador
if ($_SESSION['rol'] !== 'admin') {
    echo "No tienes permisos para realizar esta acción.";
    exit();
}

// Conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "registro_mileniumfit";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// Verificar que el formulario fue enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $titulo = $conn->real_escape_string($_POST['titulo']);
    $contenido = $conn->real_escape_string($_POST['contenido']);
    $foto = $_FILES['foto'];
   

    // Ruta de almacenamiento para las fotos
    $directorio = "uploads/";
    $ruta_foto = $directorio . basename($foto["name"]);

    // Subir la foto al servidor
    if (move_uploaded_file($foto["tmp_name"], $ruta_foto)) {
        // Guardar los datos en la base de datos
        $sql = "INSERT INTO publicaciones (titulo, contenido, foto) VALUES ('$titulo', '$contenido', '$ruta_foto')";

        if ($conn->query($sql) === TRUE) {
            echo "¡Rifa Publicada!";
        } else {
            echo "Error al guardar la publicación: " . $conn->error;
        }
    } else {
        echo "Hubo un error al subir la foto.";
    }
}



header("location: rifas.php");
exit();
$conn->close();
?>


