<!DOCTYPE html>
<html lang="es">
<head>
<style>
    
    @media (max-width: 600px) {
    body {
        font-size: 16px;
    }
}
body{background-color:black;

}
h1{text-align:center;
    font-family:Arial;
    font-size:35px;
   color: #F55C27;

}
h4{text-align:center;
    font-family:serif;
    font-size:27px;
    color:#ffd900;

}
img{width: 16px;
    height: 20px;
}


    </style>

<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="UTF-8">
    <title>confirmación participante</title>
</head>
<body>
<a href="iniciar.php">
    <img src="imagenes/flecha.png" alt="">
</a>
    <h1>¡Formulario realizado!</h1>
    <h4>Gracias por completar el formulario. Tu registro de la compra de la rifa se ha registrado con éxito.</h4>
</body>
</html>
